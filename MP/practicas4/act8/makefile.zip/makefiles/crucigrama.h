/* -------------------------------------------------------------
    Prototipos de las funciones relacionadas con crucigramas
   ------------------------------------------------------------*/
#ifndef CRUCIGRAMA_H
#define CRUCIGRAMA_H

void imprimeCrucigrama();
void creaCrucigrama();
#endif

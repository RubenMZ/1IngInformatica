/* --------------------------------------
   Funciones para reservar memoria
   --------------------------------------*/

#include <stdio.h>
#include "memoria.h"

void reservaCrucigrama(){
   printf("Reserva memoria para un crucigrama\n");
}   

void reservaSopaLetras(){
   printf("Reserva memoria para una sopa de letras\n");
}  

/* ---------------------------------------------------------
    Prototipos de las funciones relacionadas con ficheros
   --------------------------------------------------------*/
   
#ifndef FICHEROS_H
#define FICHEROS_H

void cargaFicheroBinario();
void cargaFicheroTexto();
void existeFichero();

#endif 

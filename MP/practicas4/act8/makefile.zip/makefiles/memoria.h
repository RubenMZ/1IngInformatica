/* ---------------------------------------------------------
    Prototipos de las funciones relacionadas con memoria
   --------------------------------------------------------*/
#ifndef MEMORIA_H
#define MEMORIA_H

void reservaSopaLetras();
void reservaCrucigrama();

void liberaSopaLetras();
void liberaCrucigrama();

#endif

/* --------------------------------------
   Funciones para liberar memoria
   --------------------------------------*/

#include <stdio.h>
#include "memoria.h"

void liberaCrucigrama(){
   printf("Libera la memoria de un crucigrama\n");
}   

void liberaSopaLetras(){
   printf("Libera memoria de una sopa de letras\n");
}
